#!/usr/bin/env bash
# Create an account directly (works while registrations are closed, and needs no email).
#
#   ./add-user.sh USERNAME EMAIL [user|moderator|admin|owner]      (default: user)
#
# The account is confirmed and approved straight away; its generated password is
# printed below. They can change it under Preferences → Account after logging in.
# From the web UI instead: Preferences → Invite people makes a sign-up link.
set -euo pipefail
cd "$(dirname "$0")"

usage() { echo "Usage: $0 USERNAME EMAIL [user|moderator|admin|owner]" >&2; exit 1; }
[[ $# -ge 2 && $# -le 3 ]] || usage
username=$1 email=$2 role=${3:-user}
[[ $username =~ ^[A-Za-z0-9_]+$ ]] || { echo "USERNAME may only contain letters, numbers and _" >&2; exit 1; }
[[ $email == *@*.* ]] || { echo "EMAIL doesn't look like an email address" >&2; exit 1; }

args=(accounts create "$username" --email "$email" --confirmed --approve)
case ${role,,} in
  user) ;;
  moderator) args+=(--role Moderator) ;;
  admin) args+=(--role Admin) ;;
  owner) args+=(--role Owner) ;;
  *) usage ;;
esac

docker compose exec -T web tootctl "${args[@]}"
