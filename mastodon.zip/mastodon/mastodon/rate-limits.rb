# frozen_string_literal: true

# Mounted into the Mastodon image as config/initializers/zz_stack_rate_limits.rb.
#
# Per-account anti-spam limits from .env. Mastodon fixes these in code:
#   posts (and edits)  300 per 3 hours      RateLimiter::FAMILIES[:statuses]
#   media uploads       30 per 30 minutes   Rack::Attack throttle 'throttle_api_media'
# Going over either gets a "429 Too many requests" until the period resets.
# Blank = Mastodon's default. Applied once the app has loaded, in every process.

ActiveSupport.on_load(:after_initialize) do
  setting = lambda do |var|
    raw = ENV[var].to_s.strip
    next nil if raw.empty?

    abort "#{var}=#{raw.inspect} in .env must be a whole number above 0" unless raw.match?(/\A[1-9]\d*\z/)
    raw.to_i
  end

  # --- posts ---------------------------------------------------------------
  post_limit = setting.call('POST_LIMIT')
  post_hours = setting.call('POST_LIMIT_HOURS')
  if post_limit || post_hours
    statuses = RateLimiter::FAMILIES[:statuses]
    families = RateLimiter::FAMILIES.merge(
      statuses: {
        limit: post_limit || statuses[:limit],
        period: post_hours ? post_hours.hours : statuses[:period],
      }.freeze
    ).freeze
    RateLimiter.send(:remove_const, :FAMILIES)
    RateLimiter.const_set(:FAMILIES, families)
  end

  # --- media uploads -------------------------------------------------------
  media_limit   = setting.call('MEDIA_UPLOAD_LIMIT')
  media_minutes = setting.call('MEDIA_UPLOAD_LIMIT_MINUTES')
  if media_limit || media_minutes
    current = Rack::Attack.throttles.fetch('throttle_api_media')
    # Same rule as Mastodon's config/initializers/rack_attack.rb, new numbers.
    Rack::Attack.throttle('throttle_api_media',
                          limit: media_limit || current.limit,
                          period: media_minutes ? media_minutes.minutes : current.period) do |req|
      req.authenticated_user_id if req.post? && req.path.match?(%r{\A/api/v\d+/media\z}i)
    end
  end
end
