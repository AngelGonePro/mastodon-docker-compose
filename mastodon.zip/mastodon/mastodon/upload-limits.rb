# frozen_string_literal: true

# Mounted into the Mastodon image as config/initializers/zz_stack_upload_limits.rb.
#
# Mastodon fixes its upload limits in code (MediaAttachment::IMAGE_LIMIT = 16 MB,
# VIDEO_LIMIT = 99 MB). This replaces them with MAX_IMAGE_SIZE_MB / MAX_VIDEO_SIZE_MB
# from .env once the app has loaded, in every process (web, Sidekiq, tootctl).
# Everything that reads the constants at run time follows the new values: the
# upload size check, the video transcoder's bitrate cap, and the limits the
# instance API reports to the web UI and apps (so they warn before uploading).
# Blank = Mastodon's own default.

ActiveSupport.on_load(:after_initialize) do
  {
    IMAGE_LIMIT: 'MAX_IMAGE_SIZE_MB',
    VIDEO_LIMIT: 'MAX_VIDEO_SIZE_MB',
  }.each do |const, var|
    raw = ENV[var].to_s.strip
    next if raw.empty?

    abort "#{var}=#{raw.inspect} in .env must be a whole number of megabytes (e.g. 40)" unless raw.match?(/\A[1-9]\d*\z/)

    bytes = raw.to_i * 1024 * 1024
    next if MediaAttachment.const_get(const) == bytes

    MediaAttachment.send(:remove_const, const)
    MediaAttachment.const_set(const, bytes)
  end
end
