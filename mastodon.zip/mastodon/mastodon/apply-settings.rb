# frozen_string_literal: true

# Run by the migrate service after the database is up to date, on every start:
#   bundle exec rails runner /stack/apply-settings.rb
#
# Applies the sign-up settings from .env so they can't drift from it:
#
#   REGISTRATIONS_MODE  closed   = nobody can sign up on their own (default)
#                       approval = anyone can apply, a moderator approves
#                       open     = anyone can sign up
#                       blank    = leave it to Administration → Server settings
#
#   INVITES             admins   = only admins/the owner can make invite links (default)
#                       everyone = every user can make invite links (Mastodon's default)
#                       blank    = leave it to Administration → Roles
#
# An invite link lets one person sign up even while registrations are closed,
# which is how admins add people from the web UI.

REGISTRATION_MODES = { 'closed' => 'none', 'approval' => 'approved', 'open' => 'open' }.freeze

mode = ENV['REGISTRATIONS_MODE'].to_s.strip.downcase
unless mode.empty?
  wanted = REGISTRATION_MODES[mode] ||
           abort("REGISTRATIONS_MODE=#{mode.inspect} in .env must be closed, approval or open (or blank)")
  if Setting.registrations_mode == wanted
    puts "Registrations: #{mode} (unchanged)"
  else
    Setting.registrations_mode = wanted
    puts "Registrations: set to #{mode}"
  end
end

invites = ENV['INVITES'].to_s.strip.downcase
unless invites.empty?
  abort("INVITES=#{invites.inspect} in .env must be admins or everyone (or blank)") unless %w(admins everyone).include?(invites)

  flag = UserRole::FLAGS[:invite_users]
  set_flag = lambda do |role, on|
    permissions = on ? (role.permissions | flag) : (role.permissions & ~flag)
    role.update!(permissions: permissions) unless permissions == role.permissions
  end

  # Everyone's base role decides whether ordinary users can invite.
  set_flag.call(UserRole.everyone, invites == 'everyone')
  # Admin-level roles (manage who can access the server) always can.
  # The owner's "administrator" permission already includes it.
  UserRole.where.not(id: UserRole::EVERYONE_ROLE_ID).find_each do |role|
    set_flag.call(role, true) if role.permissions & UserRole::FLAGS[:manage_user_access] != 0
  end
  puts "Invite links: #{invites}"
end
