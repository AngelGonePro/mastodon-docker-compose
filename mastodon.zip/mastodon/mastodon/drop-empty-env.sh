#!/usr/bin/env bash
# Removes every environment variable whose value is empty, then runs the
# container's command. A blank line in .env (e.g. DEFAULT_LOCALE=) then means
# "not set", so Mastodon falls back to its own default instead of choking on "".
for name in $(compgen -e); do
  [[ -z ${!name} ]] && unset "$name"
done
exec "$@"
