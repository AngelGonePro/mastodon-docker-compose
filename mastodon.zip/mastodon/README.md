# Mastodon (Docker Compose)

A self-contained Mastodon server: web (Puma), streaming (live timelines and
notifications), Sidekiq (federation and background jobs), Postgres, Redis, and
a small nginx front that is the stack's only published port. TLS is left to
your reverse proxy.

```
mastodon/
├── .env                             ← every setting lives here
├── docker-compose.yml
├── deploy-update.sh                 ← the install/update command runs this
├── add-user.sh                      ← create an account (works with sign-ups closed)
├── front/default.conf.template      ← web/streaming/media routing (port HTTP_PORT)
├── front/19-upload-limit.envsh      ← sizes the front's request limit from MAX_*_SIZE_MB
├── mastodon/upload-limits.rb        ← applies MAX_IMAGE_SIZE_MB / MAX_VIDEO_SIZE_MB
├── mastodon/rate-limits.rb          ← applies POST_LIMIT* / MEDIA_UPLOAD_LIMIT*
├── mastodon/apply-settings.rb       ← applies REGISTRATIONS_MODE / INVITES on every start
├── mastodon/drop-empty-env.sh       ← makes blank .env values mean "use Mastodon's default"
├── data/                            ← created on first start: postgres/, redis/, system/ (media)
└── backups/                         ← database dumps taken before image upgrades
```

## Install / update (same command for both)

```bash
curl -fsSL -o /tmp/mastodon.zip https://github.com/AngelGonePro/mastodon-docker-compose/raw/refs/heads/main/mastodon.zip && python3 -c "import zipfile;open('/tmp/mastodon-deploy.sh','wb').write(zipfile.ZipFile('/tmp/mastodon.zip').read('mastodon/deploy-update.sh'))" && bash /tmp/mastodon-deploy.sh /tmp/mastodon.zip ~/mastodon
```

Needs only `curl`, `python3`, `openssl` and Docker with the compose plugin (no `unzip`).

The first run puts the project in `~/mastodon`, generates the database password
and all of Mastodon's secrets (`SECRET_KEY_BASE`, the three
`ACTIVE_RECORD_ENCRYPTION_*` keys and the VAPID push keys), and stops. Check
`.env` — **`LOCAL_DOMAIN` becomes `@you@<that>` forever** — then run the same
command again to start it. That run creates the database, waits until
everything answers and, on a new server, prints the command to create your
owner account:

```bash
cd ~/mastodon && ./add-user.sh YOURNAME you@example.com owner
```

It prints a generated password. Log in, then change it under Preferences → Account.

Every later run upgrades in place:

- `.env`, `data/` and `backups/` are never overwritten. Secrets are only ever
  generated when blank, never replaced.
- Files you edited are left alone and reported.
- New `.env` keys are added with their defaults at the bottom.
- Image pins (`MASTODON_IMAGE`, `STREAMING_IMAGE`, `POSTGRES_IMAGE`,
  `REDIS_IMAGE`, `NGINX_IMAGE`) move to the release's new versions only if you
  left them at the previous release's value; a version you set yourself stays.
  A Postgres **major** version change is never applied automatically (it needs
  a dump/restore).
- Before an image changes, the new images are pulled first (nothing is changed
  if that fails) and the database is dumped to `backups/`, since Mastodon's
  database migrations are one-way.
- Database migrations run automatically (the `migrate` service) before web and
  Sidekiq start. Read Mastodon's release notes before a big version jump; some
  releases ask for extra steps.
- Nothing is deleted automatically; files a release removed are only reported.

## Reverse proxy

The two site configs ship separately (not in the zip):

1. **Home nginx-ui:** paste `proxy-nginx-social.cosmoscraft.net.conf`.
   Change `10.0.0.152:8096` (in all three blocks) if the stack lives on another VM/port.
2. **Linode nginx-ui:** paste `linode-social.cosmoscraft.net.conf`.
   Change `8444` if your `TUNNEL_LOCAL_PORT` differs. No new frpc proxy is needed.
3. **DNS:** one of the two —
   - `social` → A record to the Linode, DNS-only (grey cloud), or
   - a Cloudflare Tunnel public hostname `social.cosmoscraft.net` → `http://<home proxy IP>:80`.

Both proxy paths pass websockets through, which live timelines and
notifications need.

## Adding people

Sign-ups are closed by default (`REGISTRATIONS_MODE=closed`), so nobody can
make an account on their own. Admins add people one of two ways:

- **Web UI:** Preferences → Invite people → generate a link and send it. The
  link lets that person sign up even with registrations closed; you can limit
  how many times it works and when it expires. Only admins and the owner can
  make links (`INVITES=admins`). Without email set up, the new account can't
  confirm itself, so confirm it under Administration → Accounts → the account →
  **Confirm**.
- **Command line** (confirmed and approved straight away, no email needed):
  ```bash
  cd ~/mastodon && ./add-user.sh NAME EMAIL [user|moderator|admin|owner]
  ```
  It prints the new account's password.

`REGISTRATIONS_MODE` and `INVITES` are re-applied on every start, so `.env`
always wins over the admin UI for those two. Set either to blank to manage it
in the UI instead.

## Changing things

Edit `.env`, then run the install/update command again (or `docker compose up -d`).

- **Upload size:** `MAX_IMAGE_SIZE_MB` and `MAX_VIDEO_SIZE_MB` (whole megabytes;
  default 16 and 99). The front's request limit follows them automatically, and
  the web UI and apps are told the new limits. Cloudflare Tunnel (Free/Pro)
  refuses requests over 100 MB, so bigger videos only upload through the Linode
  or LAN path. Custom thumbnails for audio/video stay at Mastodon's 16 MB.
- **Anti-spam limits (per account):** `POST_LIMIT` posts per `POST_LIMIT_HOURS`
  (default 300 per 3 h; edits count too) and `MEDIA_UPLOAD_LIMIT` files per
  `MEDIA_UPLOAD_LIMIT_MINUTES` (default 30 per 30 min). Over a limit, the app
  shows "Too many requests" until the window resets; other accounts aren't
  affected. Windows are fixed clock blocks, not rolling.
- **Email:** fill in `SMTP_*`. Without it the server works, but sign-up
  confirmation and password-reset mails can't be sent.
- **Rules, server description, federation blocks:** in the web UI under
  Administration once you're logged in as the owner.
- **Performance:** `WEB_CONCURRENCY`, `MAX_THREADS`, `SIDEKIQ_CONCURRENCY`.

Never change `LOCAL_DOMAIN`, `WEB_DOMAIN`, or any of the generated secrets
after the server is in use.

## Useful commands

```bash
cd ~/mastodon
docker compose ps                                   # health of every service
docker compose logs -f web sidekiq streaming        # logs
docker compose exec web tootctl --help              # Mastodon's admin CLI
docker compose exec web tootctl media remove --days 7   # prune cached remote media
```

Remote media from other servers is cached under `data/system/cache` and grows
over time; the Administration → Server settings → Content retention page can
prune it automatically.
