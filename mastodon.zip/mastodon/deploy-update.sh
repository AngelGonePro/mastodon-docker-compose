#!/usr/bin/env bash
# Usage: deploy-update.sh <zip-url-or-path> [target-dir]      (target defaults to ~/mastodon)
#
# Installs mastodon on a fresh VM, or upgrades an existing install, from a release zip.
# Same rules as the other stacks' deploy-update.sh:
#   * .env, data/ and backups/ are never overwritten
#   * any other file you hand-edited since the last update is left alone and reported
#     (detected against a baseline snapshot of what was last applied)
#   * new .env keys from the template are appended with their defaults; your values stay
#   * nothing is deleted automatically — removed files are only reported
# Image pins (*_IMAGE in .env) follow a new release only if you left them at the previous
# release's value; a Postgres major-version change is never applied automatically. Before an
# image changes, the new images are pulled first (nothing changes if that fails) and the
# database is dumped to backups/, since Mastodon's database migrations are one-way.
# The first run only puts the files in place (with a generated database password and all of
# Mastodon's secrets) and stops, so you can check .env — LOCAL_DOMAIN is permanent. Every
# later run (re)starts the stack, which runs any database migrations, and waits for it to answer.
set -euo pipefail

# Run from a private copy so this script can safely replace its own installed file.
if [[ -z ${MDN_DEPLOY_COPY:-} ]]; then
  self_copy=$(mktemp)
  cp "$0" "$self_copy"
  MDN_DEPLOY_COPY=$self_copy exec bash "$self_copy" "$@"
fi
trap 'rm -f "$MDN_DEPLOY_COPY"' EXIT

PROJECT=mastodon
HEALTH_TIMEOUT=${HEALTH_TIMEOUT:-600}

for cmd in curl python3 openssl docker; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing dependency: $cmd" >&2
    [[ $cmd == docker ]] && echo "Install Docker Engine + the compose plugin first." >&2 \
                         || echo "Install it first: sudo apt update && sudo apt install -y $cmd" >&2
    exit 1
  fi
done
docker compose version >/dev/null 2>&1 || { echo "The docker compose plugin is missing." >&2; exit 1; }

SOURCE="${1:?Usage: $0 <zip-url-or-path> [target-dir]}"
TARGET_DIR="${2:-$HOME/$PROJECT}"

if [[ $(basename "$PWD") == "$TARGET_DIR" ]] && { [[ -f docker-compose.yml ]] || [[ -f .env ]]; }; then
  echo "You're already inside '$TARGET_DIR' with an existing deployment — using '.' instead of nesting." >&2
  TARGET_DIR="."
fi

HARD_PROTECTED_PATHS="
.env
.deploy-baseline
data
backups
"
BASELINE_DIR="$TARGET_DIR/.deploy-baseline"

is_hard_protected() {
  local path=$1 p
  for p in $HARD_PROTECTED_PATHS ${EXTRA_PROTECTED:-}; do
    case "$path" in "$p"|"$p"/*) return 0 ;; esac
  done
  return 1
}

WORK=$(mktemp -d)
trap 'rm -f "$MDN_DEPLOY_COPY"; rm -rf "$WORK"' EXIT
TMP_ZIP="$WORK/release.zip"
TMP_EXTRACT="$WORK/extract"
mkdir -p "$TMP_EXTRACT"

if [[ $SOURCE =~ ^(https?|file):// ]]; then
  echo "==> Downloading $SOURCE"
  curl -fsSL -o "$TMP_ZIP" "$SOURCE"
else
  [[ -f $SOURCE ]] || { echo "Zip not found: $SOURCE" >&2; exit 1; }
  cp "$SOURCE" "$TMP_ZIP"
fi

echo "==> Extracting (stripping the top-level folder)"
python3 -I - "$TMP_ZIP" "$TMP_EXTRACT" << 'PYEOF'
import zipfile, os, sys
zip_path, extract_to = sys.argv[1], os.path.realpath(sys.argv[2])
try:
    z = zipfile.ZipFile(zip_path)
except zipfile.BadZipFile:
    sys.exit("The download isn't a zip file — check the URL (GitHub returns a small '404: Not Found' page for a wrong repo or file name).")
with z:
    for info in z.infolist():
        parts = info.filename.split("/", 1)
        if len(parts) < 2 or not parts[1] or info.filename.endswith("/"):
            continue
        target = os.path.realpath(os.path.join(extract_to, parts[1]))
        if not target.startswith(extract_to + os.sep):
            sys.exit(f"refusing unsafe path in zip: {info.filename}")
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(z.read(info))
        mode = (info.external_attr >> 16) & 0o777
        if mode:
            os.chmod(target, mode)
PYEOF
[[ -f $TMP_EXTRACT/docker-compose.yml && -f $TMP_EXTRACT/.env ]] || { echo "This zip doesn't look like a $PROJECT release." >&2; exit 1; }

env_value() { # key file
  [[ -f $2 ]] || return 0
  # a key that isn't there yet (older .env) is just empty — never an error
  { grep -E "^$1=" "$2" || true; } | tail -n1 | cut -d= -f2- | sed -e 's/^["'\'']//' -e 's/["'\'']$//'
}

# ------------------------------------------------- generate missing secrets (once) ---
# Only blank values are filled; a value that's already there is never replaced.
set_env() { # file key value
  if grep -q "^$2=" "$1"; then
    python3 -I - "$1" "$2" "$3" <<'PYEOF'
import sys
path, key, value = sys.argv[1:4]
lines = open(path).read().splitlines(True)
for i, l in enumerate(lines):
    if l.startswith(key + "="):
        lines[i] = f"{key}={value}\n"
open(path, "w").writelines(lines)
PYEOF
  else
    printf '%s=%s\n' "$2" "$3" >> "$1"
  fi
}
rand() { python3 -I -c "import secrets,sys; print(secrets.token_$1(int(sys.argv[1])))" "$2"; }

generate_secrets() { # envfile — fills blank secrets only; sets GENERATED
  local envfile=$1 key val vapid
  GENERATED=""
  for key in POSTGRES_PASSWORD SECRET_KEY_BASE ACTIVE_RECORD_ENCRYPTION_DETERMINISTIC_KEY \
             ACTIVE_RECORD_ENCRYPTION_KEY_DERIVATION_SALT ACTIVE_RECORD_ENCRYPTION_PRIMARY_KEY; do
    [[ -n $(env_value "$key" "$envfile") ]] && continue
    case $key in
      SECRET_KEY_BASE) val=$(rand hex 64) ;;          # 128 hex chars, like `rails secret`
      POSTGRES_PASSWORD) val=$(rand urlsafe 36) ;;
      *) val=$(rand urlsafe 32) ;;
    esac
    set_env "$envfile" "$key" "$val"; GENERATED+="$key "
  done

  # Web-push (VAPID) keys: a P-256 key pair, URL-safe base64 — the same format as
  # Mastodon's own `rake mastodon:webpush:generate_vapid_key`. Both are generated
  # together, and only if both are blank.
  if [[ -z $(env_value VAPID_PRIVATE_KEY "$envfile") && -z $(env_value VAPID_PUBLIC_KEY "$envfile") ]]; then
    vapid=$(openssl ecparam -name prime256v1 -genkey -noout -outform DER | python3 -I -c '
import sys, base64
der = sys.stdin.buffer.read()
# SEC1 ECPrivateKey for P-256: 30 77 02 01 01 04 20 <32-byte private key> a0 0a <curve oid>
#                              a1 44 03 42 00 <65-byte uncompressed public key>
assert der[:7] == bytes.fromhex("30770201010420") and der[-68:-65] == bytes.fromhex("034200") and der[-65] == 4, "unexpected key format"
priv, pub = der[7:39], der[-65:]
print(base64.urlsafe_b64encode(priv).decode(), base64.urlsafe_b64encode(pub).decode())
')
    set_env "$envfile" VAPID_PRIVATE_KEY "${vapid% *}"
    set_env "$envfile" VAPID_PUBLIC_KEY "${vapid#* }"
    GENERATED+="VAPID_PRIVATE_KEY VAPID_PUBLIC_KEY "
  elif [[ -z $(env_value VAPID_PRIVATE_KEY "$envfile") || -z $(env_value VAPID_PUBLIC_KEY "$envfile") ]]; then
    echo "    ! Only one of VAPID_PRIVATE_KEY / VAPID_PUBLIC_KEY is set — set both, or blank both to regenerate." >&2
  fi
}

check_settings() { # envfile — catches typos before anything is changed or started
  local envfile=$1 bad="" v
  for k in MAX_IMAGE_SIZE_MB MAX_VIDEO_SIZE_MB; do
    v=$(env_value "$k" "$envfile")
    [[ -z $v || $v =~ ^[1-9][0-9]*$ ]] || bad+="      $k=$v  (must be a whole number of megabytes, e.g. 40)"$'\n'
  done
  for k in POST_LIMIT POST_LIMIT_HOURS MEDIA_UPLOAD_LIMIT MEDIA_UPLOAD_LIMIT_MINUTES; do
    v=$(env_value "$k" "$envfile")
    [[ -z $v || $v =~ ^[1-9][0-9]*$ ]] || bad+="      $k=$v  (must be a whole number above 0)"$'\n'
  done
  v=$(env_value REGISTRATIONS_MODE "$envfile" | tr '[:upper:]' '[:lower:]')
  [[ -z $v || $v =~ ^(closed|approval|open)$ ]] || bad+="      REGISTRATIONS_MODE=$v  (must be closed, approval or open)"$'\n'
  v=$(env_value INVITES "$envfile" | tr '[:upper:]' '[:lower:]')
  [[ -z $v || $v =~ ^(admins|everyone)$ ]] || bad+="      INVITES=$v  (must be admins or everyone)"$'\n'
  if [[ -n $bad ]]; then
    printf 'These .env values are invalid:\n%s' "$bad" >&2
    return 1
  fi
}

mkdir -p "$TARGET_DIR" "$BASELINE_DIR"
FIRST_INSTALL=0
[[ -f $TARGET_DIR/.env ]] || FIRST_INSTALL=1

# A custom DATA_DIR inside the project is runtime state too.
DATA_DIR_VALUE=$(env_value DATA_DIR "$TARGET_DIR/.env"); DATA_DIR_VALUE=${DATA_DIR_VALUE:-./data}
case "$DATA_DIR_VALUE" in /*) ;; *) EXTRA_PROTECTED="${DATA_DIR_VALUE#./}" ;; esac

# ------------------------------------------------------------ work out the new .env ---
# (done before any file is touched, so a bad release or failed pull changes nothing)
IMAGES_CHANGED=0
DB_MAJOR_BLOCKED=0
GENERATED=""
if [[ $FIRST_INSTALL == 0 ]]; then
  MERGED="$WORK/merged.env"
  cp -p "$TARGET_DIR/.env" "$MERGED"
  OLD_TEMPLATE="$BASELINE_DIR/.env.template"   # the .env template of the release you're on now
  NEW_KEYS=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$MERGED" || NEW_KEYS+="$line"$'\n'
  done < "$TMP_EXTRACT/.env"

  PIN_REPORT=""
  major() { printf '%s' "${1##*:}" | grep -oE '^[0-9]+' || true; }
  while IFS= read -r key; do
    mine=$(env_value "$key" "$MERGED"); new=$(env_value "$key" "$TMP_EXTRACT/.env"); old=$(env_value "$key" "$OLD_TEMPLATE")
    [[ -n $mine && -n $new && $mine != "$new" ]] || continue
    if [[ $key == POSTGRES_IMAGE && $(major "$mine") != "$(major "$new")" ]]; then
      PIN_REPORT+="      ! $key: release uses $new — a Postgres MAJOR version change, NOT applied"$'\n'
      PIN_REPORT+="        automatically (the data needs a dump/restore). Staying on $mine."$'\n'
      DB_MAJOR_BLOCKED=1
    elif [[ -n $old && $mine == "$old" ]]; then
      sed -i "s|^${key}=.*|${key}=${new}|" "$MERGED"
      PIN_REPORT+="      ~ $key: $mine -> $new"$'\n'
      IMAGES_CHANGED=1
    elif [[ -z $old ]]; then
      PIN_REPORT+="      = $key: kept $mine (no baseline yet to tell whether you set it; release uses $new)"$'\n'
    else
      PIN_REPORT+="      = $key: you set $mine yourself — kept (release uses $new)"$'\n'
    fi
  done < <(grep -oE '^[A-Z0-9_]+_IMAGE=' "$TMP_EXTRACT/.env" | tr -d '=')
  # web and streaming must run the same Mastodon version
  m_tag=$(env_value MASTODON_IMAGE "$MERGED"); s_tag=$(env_value STREAMING_IMAGE "$MERGED")
  if [[ -n $m_tag && -n $s_tag && ${m_tag##*:} != "${s_tag##*:}" ]]; then
    PIN_REPORT+="      ! MASTODON_IMAGE (${m_tag##*:}) and STREAMING_IMAGE (${s_tag##*:}) are different versions — set them to the same tag"$'\n'
  fi
  if [[ -n $NEW_KEYS ]]; then
    { echo ""; echo "# --- New in this update ($(date -u +'%Y-%m-%dT%H:%M:%SZ')) — review these ---"
      printf '%s' "$NEW_KEYS"; } >> "$MERGED"
  fi

  generate_secrets "$MERGED"
  check_settings "$MERGED" || { echo "Nothing was changed." >&2; exit 1; }

  echo "==> Checking the new release against your .env"
  docker compose --project-directory "$TARGET_DIR" -f "$TMP_EXTRACT/docker-compose.yml" --env-file "$MERGED" config -q \
    || { echo "The new release doesn't work with your .env — nothing was changed." >&2; exit 1; }

  if [[ $IMAGES_CHANGED == 1 ]]; then
    echo "==> Pulling the new images first (nothing is changed if this fails)"
    docker compose --project-directory "$TARGET_DIR" -f "$TMP_EXTRACT/docker-compose.yml" --env-file "$MERGED" pull \
      || { echo "Image pull failed — nothing was changed." >&2; exit 1; }
    if (cd "$TARGET_DIR" && docker compose ps --status running --services 2>/dev/null | grep -qx db); then
      mkdir -p "$TARGET_DIR/backups"
      STAMP=$(date -u +%Y%m%d-%H%M%S)
      DUMP="$TARGET_DIR/backups/mastodon-$STAMP.sql.gz"
      echo "==> Backing up the database before the upgrade: $DUMP"
      if ! (cd "$TARGET_DIR" && docker compose exec -T db sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB"') | gzip > "$DUMP" \
         || [[ $(gzip -dc "$DUMP" | head -c 1 | wc -c) -eq 0 ]]; then
        rm -f "$DUMP"
        echo "Database backup failed — nothing was changed." >&2
        exit 1
      fi
    fi
  fi
fi

echo "==> Applying updates"
NEW_LIST="$WORK/new" EDITED_LIST="$WORK/edited" UNTRACKED_LIST="$WORK/untracked" UPDATED_LIST="$WORK/updated"
: > "$NEW_LIST"; : > "$EDITED_LIST"; : > "$UNTRACKED_LIST"; : > "$UPDATED_LIST"
while IFS= read -r relpath; do
  is_hard_protected "$relpath" && continue
  target_file="$TARGET_DIR/$relpath"
  baseline_file="$BASELINE_DIR/$relpath"
  new_file="$TMP_EXTRACT/$relpath"

  if [[ ! -e $target_file ]]; then
    mkdir -p "$(dirname "$target_file")"
    cp -p "$new_file" "$target_file"
    echo "$relpath" >> "$NEW_LIST"
  elif [[ -f $baseline_file ]] && cmp -s "$target_file" "$baseline_file"; then
    # untouched since the last update — safe to replace
    if ! cmp -s "$new_file" "$target_file"; then
      cp -p "$new_file" "$target_file"
      echo "$relpath" >> "$UPDATED_LIST"
    fi
  elif [[ -f $baseline_file ]]; then
    # you edited it since the last update — leave it
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$EDITED_LIST"
  else
    # pre-existing file with no baseline yet — leave it this once
    cmp -s "$new_file" "$target_file" || echo "$relpath" >> "$UNTRACKED_LIST"
  fi
  mkdir -p "$(dirname "$baseline_file")"
  cp -p "$new_file" "$baseline_file"
done < <(cd "$TMP_EXTRACT" && find . -type f | sed 's#^\./##' | sort)

if [[ -s $NEW_LIST && $FIRST_INSTALL == 0 ]]; then echo "    New files added:"; sed 's/^/      /' "$NEW_LIST"; fi
if [[ -s $UPDATED_LIST ]]; then echo "    Updated:"; sed 's/^/      /' "$UPDATED_LIST"; fi
if [[ -s $EDITED_LIST ]]; then
  echo "    Hand-edited by you since the last update — left untouched. To see the new version:"
  while IFS= read -r f; do echo "      diff $TARGET_DIR/$f $BASELINE_DIR/$f"; done < "$EDITED_LIST"
fi
if [[ -s $UNTRACKED_LIST ]]; then
  echo "    First time comparing these against a template — left alone this once; tracked from now on:"
  sed 's/^/      /' "$UNTRACKED_LIST"
fi
[[ $FIRST_INSTALL == 1 || -s $NEW_LIST || -s $UPDATED_LIST || -s $EDITED_LIST || -s $UNTRACKED_LIST ]] || echo "    Already up to date."

if [[ $FIRST_INSTALL == 0 ]]; then
  echo "==> Checking for files this update removed (reported only, nothing deleted)"
  ORPHANS=$(cd "$TARGET_DIR" && find . -path ./.deploy-baseline -prune -o -type f -print | sed 's#^\./##' | sort | while IFS= read -r f; do
    is_hard_protected "$f" && continue
    [[ -e $BASELINE_DIR/$f && ! -e $TMP_EXTRACT/$f ]] && echo "$f"
  done || true)
  if [[ -n $ORPHANS ]]; then
    echo "    No longer part of the project — safe to remove:"
    sed "s#^#      rm $TARGET_DIR/#" <<<"$ORPHANS"
    while IFS= read -r f; do rm -f "$BASELINE_DIR/$f"; done <<<"$ORPHANS"
  else
    echo "    Nothing orphaned."
  fi
fi

echo "==> Merging .env"
if [[ $FIRST_INSTALL == 0 ]]; then
  cp -p "$TARGET_DIR/.env" "$TARGET_DIR/.env.bak"
  cp "$MERGED" "$TARGET_DIR/.env"
  chmod 600 "$TARGET_DIR/.env"
  if [[ -n $NEW_KEYS ]]; then
    echo "    New .env keys added with their defaults (bottom of $TARGET_DIR/.env):"
    printf '%s' "$NEW_KEYS" | sed 's/^/      /'
  else
    echo "    No new .env keys."
  fi
  [[ -n $PIN_REPORT ]] && { echo "    Image versions:"; printf '%s' "$PIN_REPORT"; }
  echo "    All your other values were left exactly as they were (previous copy: .env.bak)."
  OBSOLETE=""
  while IFS= read -r line || [[ -n $line ]]; do
    case "$line" in \#*|"") continue ;; esac
    key=${line%%=*}
    grep -q "^${key}=" "$TMP_EXTRACT/.env" || OBSOLETE+="$key"$'\n'
  done < "$TARGET_DIR/.env"
  if [[ -n $OBSOLETE ]]; then
    echo "    No longer used by the template (left in place):"
    printf '%s' "$OBSOLETE" | sed 's/^/      /'
  fi
else
  cp "$TMP_EXTRACT/.env" "$TARGET_DIR/.env"
  chmod 600 "$TARGET_DIR/.env"
  echo "    No existing .env — copied the template."
  generate_secrets "$TARGET_DIR/.env"
fi
[[ -n $GENERATED ]] && echo "    Generated (saved in .env, never changed again): $GENERATED"
cp -p "$TMP_EXTRACT/.env" "$BASELINE_DIR/.env.template"

chmod 755 "$TARGET_DIR"/deploy-update.sh "$TARGET_DIR"/add-user.sh "$TARGET_DIR"/mastodon/drop-empty-env.sh \
          "$TARGET_DIR"/front/19-upload-limit.envsh 2>/dev/null || true   # nginx only runs the .envsh if it's executable
chmod 644 "$TARGET_DIR"/front/default.conf.template "$TARGET_DIR"/mastodon/upload-limits.rb "$TARGET_DIR"/mastodon/rate-limits.rb \
          "$TARGET_DIR"/mastodon/apply-settings.rb 2>/dev/null || true

echo ""
if [[ $FIRST_INSTALL == 1 ]]; then
  echo "==> Files are in place in $TARGET_DIR, but nothing was started yet."
  echo "    Check these in $TARGET_DIR/.env first — LOCAL_DOMAIN can never be changed later:"
  for k in LOCAL_DOMAIN WEB_DOMAIN HTTP_PORT MAX_IMAGE_SIZE_MB MAX_VIDEO_SIZE_MB REGISTRATIONS_MODE INVITES SMTP_SERVER; do
    printf '      %s=%s\n' "$k" "$(env_value "$k" "$TARGET_DIR/.env")"
  done
  echo "    then run the same install/update command again to start it."
  exit 0
fi

# ---------------------------------------------------------------- start / restart ---
cd "$TARGET_DIR"
check_settings .env || { echo "Fix them in $(pwd)/.env and run the install/update command again." >&2; exit 1; }
DATA_DIR_VALUE=$(env_value DATA_DIR .env); DATA_DIR_VALUE=${DATA_DIR_VALUE:-./data}
mkdir -p "$DATA_DIR_VALUE/postgres" "$DATA_DIR_VALUE/redis" "$DATA_DIR_VALUE/system"

# The front's port must be free (or already be this stack's own front).
PORT=$(env_value HTTP_PORT .env); PORT=${PORT:-8110}
if command -v ss >/dev/null 2>&1 && [[ -n $(ss -Htln "sport = :$PORT" 2>/dev/null) ]] \
   && ! docker compose ps --status running --services 2>/dev/null | grep -qx front; then
  echo "    Port $PORT (HTTP_PORT in .env) is already used by something else on this machine:" >&2
  ss -Htlnp "sport = :$PORT" 2>/dev/null | sed 's/^/      /' >&2
  echo "    Set HTTP_PORT in $(pwd)/.env to a free port, point your reverse proxy at it," >&2
  echo "    and run the install/update command again. Check a port is free with:" >&2
  echo "      ss -ltnp 'sport = :PORT'" >&2
  exit 1
fi

echo "==> Starting / updating the stack (database migrations run first)"
if ! docker compose up -d --remove-orphans; then
  echo "    'docker compose up' failed. Migration log:" >&2
  docker compose logs --tail 40 migrate >&2 || true
  echo "    Fix .env (previous copy: .env.bak) and run the install/update command again." >&2
  exit 1
fi

HOSTNAME_=$(env_value WEB_DOMAIN .env); HOSTNAME_=${HOSTNAME_:-$(env_value LOCAL_DOMAIN .env)}
echo "==> Waiting up to ${HEALTH_TIMEOUT}s for Mastodon to answer"
deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
status="not checked"
while (( $(date +%s) < deadline )); do
  states=""
  for svc in db redis web streaming sidekiq front; do
    cid=$(docker compose ps -q "$svc" 2>/dev/null || true)
    st=$( [[ -n $cid ]] && docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' "$cid" 2>/dev/null || echo missing)
    states+="$svc=$st "
  done
  status=$states
  all_healthy=1
  for svc in db redis web streaming sidekiq front; do [[ $states == *"$svc=healthy"* ]] || all_healthy=0; done
  (( all_healthy )) && status+="(but nothing answers on port $PORT)"
  if (( all_healthy )) \
     && curl -fs --noproxy '*' -o /dev/null -H "Host: $HOSTNAME_" -H "X-Forwarded-Proto: https" "http://127.0.0.1:$PORT/health" 2>/dev/null \
     && curl -fs --noproxy '*' -o /dev/null -H "Host: $HOSTNAME_" -H "X-Forwarded-Proto: https" "http://127.0.0.1:$PORT/api/v1/streaming/health" 2>/dev/null; then
    echo "    ok — Mastodon and its streaming API answer on port $PORT ($states)"
    echo ""
    echo "==> Done."
    if [[ $(docker compose exec -T db sh -c 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -tAc "select count(*) from users"' 2>/dev/null | tr -d '[:space:]') == 0 ]]; then
      echo "    No accounts yet. Create your owner account (prints its password):"
      echo "      cd $(pwd) && ./add-user.sh YOURNAME you@example.com owner"
    fi
    echo "    Add people:  cd $(pwd) && ./add-user.sh NAME EMAIL [user|moderator|admin]"
    echo "                 or Preferences -> Invite people in the web UI"
    [[ $DB_MAJOR_BLOCKED == 1 ]] && echo "    (see the Postgres note under 'Image versions' above)"
    echo "    Logs:  cd $(pwd) && docker compose logs -f"
    exit 0
  fi
  # A failed migration never gets better by waiting.
  mcid=$(docker compose ps -a -q migrate 2>/dev/null || true)
  if [[ -n $mcid && $(docker inspect -f '{{.State.Status}} {{.State.ExitCode}}' "$mcid" 2>/dev/null) == exited\ [1-9]* ]]; then
    status="database migration failed"
    break
  fi
  sleep 3
done

echo "    The stack never became healthy: $status" >&2
echo "---- last log lines ----" >&2
docker compose logs --tail 30 migrate web streaming sidekiq front >&2 || true
echo "------------------------" >&2
echo "    Fix .env (previous copy: .env.bak) and run the install/update command again." >&2
exit 1
